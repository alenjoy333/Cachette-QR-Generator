Cachette-QR-Generator
=====================
Cachette QR Generator is a simple QR Code Generator using Zxing Library for Windows Phone 7
